import React from "react";
import "./Footer.css";

const Footer = () => {
    return ( <
        div className = "footer" >
        <
        h3 > VirtualMed < /h3>{" "} <
        p > Asistentul tău virtual pentru consultații medicale < /p> <
        /div>
    );
};

export default Footer;